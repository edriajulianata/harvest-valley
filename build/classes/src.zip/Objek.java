import javax.swing.*;
public class Objek{
	//atribut
	public int x,y;
	public String nama;
	public JLabel pic;

	
}