public interface Movable {

	public void moveTo(int dx, int dy);
	public void moveAmount(int dx, int dy);
	public void resetPosition();
	
}
